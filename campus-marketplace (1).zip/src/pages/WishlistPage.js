"use client"
import React from "react"
import { Link } from "react-router-dom"
import { useWishlist } from "../contexts/WishlistContext.js"
import { useCart } from "../contexts/CartContext.js"
import Navbar from "../components/layout/Navbar.js"
import Footer from "../components/layout/Footer.js"
import ProductCard from "../components/common/ProductCard.js"

const WishlistPage = () => {
  const { wishlistItems, removeFromWishlist } = useWishlist()
  const { addToCart } = useCart()

  const handleMoveAllToBag = () => {
    wishlistItems.forEach((item) => {
      addToCart(item)
      removeFromWishlist(item.id)
    })
  }

  const recommendedProducts = [
    {
      id: 201,
      name: "ASUS FHD Gaming Laptop",
      price: 15600000,
      originalPrice: 24000000,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.3,
      reviews: 325,
      discount: 35,
    },
    {
      id: 202,
      name: "IPS LCD Gaming Monitor",
      price: 3700000,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.6,
      reviews: 99,
    },
  ]

  return React.createElement(
    "div",
    { className: "min-h-screen bg-gray-50" },
    React.createElement(Navbar),

    React.createElement(
      "main",
      { className: "py-8" },
      React.createElement(
        "div",
        { className: "container mx-auto px-4" },
        // Wishlist Header
        React.createElement(
          "div",
          { className: "flex items-center justify-between mb-8" },
          React.createElement(
            "h1",
            { className: "text-2xl font-bold text-gray-800" },
            `Wishlist (${wishlistItems.length})`,
          ),
          wishlistItems.length > 0 &&
            React.createElement(
              "button",
              { onClick: handleMoveAllToBag, className: "btn-secondary" },
              "Move All To Bag",
            ),
        ),

        // Wishlist Items
        wishlistItems.length === 0
          ? React.createElement(
              "div",
              { className: "text-center py-16" },
              React.createElement(
                "div",
                { className: "max-w-md mx-auto" },
                React.createElement("img", {
                  src: "/placeholder.svg?height=200&width=200",
                  alt: "Empty Wishlist",
                  className: "w-32 h-32 mx-auto mb-6 opacity-50",
                }),
                React.createElement(
                  "h2",
                  { className: "text-2xl font-bold text-gray-800 mb-4" },
                  "Your wishlist is empty",
                ),
                React.createElement(
                  "p",
                  { className: "text-gray-600 mb-8" },
                  "Save items you like to your wishlist for easy access later.",
                ),
                React.createElement(Link, { to: "/category", className: "btn-primary" }, "Continue Shopping"),
              ),
            )
          : React.createElement(
              "div",
              { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16" },
              wishlistItems.map((product) =>
                React.createElement(ProductCard, { key: product.id, product: product, showDiscount: true }),
              ),
            ),

        // Recommended Products
        React.createElement(
          "section",
          null,
          React.createElement(
            "div",
            { className: "flex items-center justify-between mb-8" },
            React.createElement(
              "h2",
              { className: "text-2xl font-bold text-gray-800" },
              React.createElement("span", { className: "text-atrace-orange" }, "■"),
              " Just For You",
            ),
            React.createElement(
              Link,
              { to: "/category", className: "text-atrace-orange hover:text-atrace-orange-dark font-medium" },
              "See All",
            ),
          ),
          React.createElement(
            "div",
            { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" },
            recommendedProducts.map((product) =>
              React.createElement(ProductCard, { key: product.id, product: product, showDiscount: true }),
            ),
          ),
        ),
      ),
    ),

    React.createElement(Footer),
  )
}

export default WishlistPage
