"use client"

import React, { useState } from "react"
import { useSearchParams } from "react-router-dom"
import Navbar from "../components/layout/Navbar.js"
import Footer from "../components/layout/Footer.js"
import ProductCard from "../components/common/ProductCard.js"

const CategoryPage = () => {
  const [searchParams] = useSearchParams()
  const [selectedCategories, setSelectedCategories] = useState([])
  const [selectedBrands, setSelectedBrands] = useState([])
  const [priceRange, setPriceRange] = useState({ min: "", max: "" })
  const [sortBy, setSortBy] = useState("most-relevant")

  // Mock data
  const categories = [
    { id: "elektronik", name: "Elektronik", count: 245 },
    { id: "fashion", name: "Fashion", count: 189 },
    { id: "rumah-gaya-hidup", name: "Rumah & Gaya Hidup", count: 156 },
    { id: "kecantikan-kesehatan", name: "Kecantikan & Kesehatan", count: 98 },
    { id: "olahraga-outdoor", name: "Olahraga & Outdoor", count: 87 },
    { id: "otomotif", name: "Otomotif", count: 76 },
    { id: "handphone-aksesoris", name: "Handphone & Aksesoris", count: 234 },
  ]

  const brands = [
    { id: "proy", name: "Proy" },
    { id: "havit", name: "HAVIT" },
    { id: "logitech", name: "Logitech" },
    { id: "razer", name: "Razer" },
    { id: "steelseries", name: "SteelSeries" },
  ]

  const products = [
    {
      id: 1,
      name: "Headset / Earphone Original Proy G8 Series",
      price: 10500,
      originalPrice: 15000,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.2,
      reviews: 89,
      discount: 30,
      badge: "Proy",
    },
    {
      id: 2,
      name: "AK-300 Wired Keyboard",
      price: 8000000,
      originalPrice: 11000000,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.5,
      reviews: 150,
      discount: 27,
      badge: "Proy",
    },
    {
      id: 3,
      name: "HAVIT HV-G92 Gamepad",
      price: 1965000,
      originalPrice: 2500000,
      image: "/placeholder.svg?height=200&width=200",
      rating: 4.8,
      reviews: 234,
      discount: 21,
      badge: "Proy",
    },
  ]

  const handleCategoryChange = (categoryId) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  const handleBrandChange = (brandId) => {
    setSelectedBrands((prev) => (prev.includes(brandId) ? prev.filter((id) => id !== brandId) : [...prev, brandId]))
  }

  return React.createElement(
    "div",
    { className: "min-h-screen bg-gray-50" },
    React.createElement(Navbar),

    React.createElement(
      "main",
      { className: "py-8" },
      React.createElement(
        "div",
        { className: "container mx-auto px-4" },
        React.createElement(
          "div",
          { className: "grid grid-cols-1 lg:grid-cols-4 gap-8" },
          // Sidebar Filters
          React.createElement(
            "div",
            { className: "lg:col-span-1" },
            React.createElement(
              "div",
              { className: "bg-white rounded-lg shadow-md p-6 sticky top-24" },
              React.createElement(
                "h3",
                { className: "text-lg font-semibold text-gray-800 mb-4" },
                React.createElement("span", { className: "text-atrace-orange" }, "■"),
                " Filter Berdasarkan",
              ),

              // Category Filter
              React.createElement(
                "div",
                { className: "mb-6" },
                React.createElement("h4", { className: "font-medium text-gray-800 mb-3" }, "Kategori"),
                React.createElement(
                  "div",
                  { className: "space-y-2" },
                  categories.map((category) =>
                    React.createElement(
                      "label",
                      { key: category.id, className: "flex items-center space-x-2 cursor-pointer" },
                      React.createElement("input", {
                        type: "checkbox",
                        checked: selectedCategories.includes(category.id),
                        onChange: () => handleCategoryChange(category.id),
                        className: "rounded border-gray-300 text-atrace-orange focus:ring-atrace-orange",
                      }),
                      React.createElement("span", { className: "text-sm text-gray-700" }, category.name),
                      React.createElement("span", { className: "text-xs text-gray-500" }, `(${category.count})`),
                    ),
                  ),
                ),
              ),

              // Brand Filter
              React.createElement(
                "div",
                { className: "mb-6" },
                React.createElement("h4", { className: "font-medium text-gray-800 mb-3" }, "Brand"),
                React.createElement(
                  "div",
                  { className: "space-y-2" },
                  brands.map((brand) =>
                    React.createElement(
                      "label",
                      { key: brand.id, className: "flex items-center space-x-2 cursor-pointer" },
                      React.createElement("input", {
                        type: "checkbox",
                        checked: selectedBrands.includes(brand.id),
                        onChange: () => handleBrandChange(brand.id),
                        className: "rounded border-gray-300 text-atrace-orange focus:ring-atrace-orange",
                      }),
                      React.createElement("span", { className: "text-sm text-gray-700" }, brand.name),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Main Content
          React.createElement(
            "div",
            { className: "lg:col-span-3" },
            // Results Header
            React.createElement(
              "div",
              { className: "flex items-center justify-between mb-6" },
              React.createElement("p", { className: "text-gray-600" }, "Menampilkan 3 produk"),
              React.createElement(
                "div",
                { className: "flex items-center space-x-2" },
                React.createElement("span", { className: "text-sm text-gray-600" }, "Urutkan:"),
                React.createElement(
                  "select",
                  {
                    value: sortBy,
                    onChange: (e) => setSortBy(e.target.value),
                    className:
                      "px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-atrace-orange",
                  },
                  React.createElement("option", { value: "most-relevant" }, "Paling Relevan"),
                  React.createElement("option", { value: "price-low-high" }, "Harga: Rendah ke Tinggi"),
                  React.createElement("option", { value: "price-high-low" }, "Harga: Tinggi ke Rendah"),
                  React.createElement("option", { value: "newest" }, "Terbaru"),
                  React.createElement("option", { value: "rating" }, "Rating Tertinggi"),
                ),
              ),
            ),

            // Products Grid
            React.createElement(
              "div",
              { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" },
              products.map((product) =>
                React.createElement(ProductCard, { key: product.id, product: product, showDiscount: true }),
              ),
            ),
          ),
        ),
      ),
    ),

    React.createElement(Footer),
  )
}

export default CategoryPage
