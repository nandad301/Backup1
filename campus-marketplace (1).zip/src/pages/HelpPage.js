"use client"

import React, { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import Navbar from "../components/layout/Navbar.js"
import Footer from "../components/layout/Footer.js"

const HelpPage = () => {
  const [searchQuery, setSearchQuery] = useState("")
  const [openFAQ, setOpenFAQ] = useState(null)

  const faqData = [
    {
      id: 1,
      question: "Bagaimana cara menggunakan kupon diskon?",
      answer:
        "Anda dapat menggunakan kupon diskon dengan memasukkan kode kupon pada halaman checkout. Pastikan kupon masih berlaku dan memenuhi syarat minimum pembelian.",
    },
    {
      id: 2,
      question: "Apa itu free ongkir dan bagaimana cara mendapatkannya?",
      answer:
        "Free ongkir adalah gratis biaya pengiriman untuk pembelian dengan minimum tertentu. Biasanya berlaku untuk pembelian di atas Rp 100.000 ke seluruh Indonesia.",
    },
    {
      id: 3,
      question: "Apa saja metode pembayaran yang tersedia?",
      answer:
        "Kami menerima berbagai metode pembayaran seperti transfer bank, e-wallet (OVO, GoPay, DANA), kartu kredit, dan COD (Cash on Delivery).",
    },
  ]

  const toggleFAQ = (id) => {
    setOpenFAQ(openFAQ === id ? null : id)
  }

  const handleSearch = (e) => {
    e.preventDefault()
    console.log("Searching for:", searchQuery)
  }

  return React.createElement(
    "div",
    { className: "min-h-screen bg-gray-50" },
    React.createElement(Navbar),

    React.createElement(
      "main",
      null,
      // Hero Section
      React.createElement(
        "section",
        { className: "bg-gradient-to-r from-atrace-orange to-yellow-400 text-white py-16" },
        React.createElement(
          "div",
          { className: "container mx-auto px-4 text-center" },
          React.createElement(
            "div",
            { className: "max-w-2xl mx-auto bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20" },
            React.createElement("h1", { className: "text-3xl font-bold mb-4" }, "Ask us anything"),
            React.createElement("p", { className: "text-lg mb-6" }, "Have any questions? We're here to assist you."),

            React.createElement(
              "form",
              { onSubmit: handleSearch, className: "relative" },
              React.createElement("input", {
                type: "text",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value),
                placeholder: "Search for answers...",
                className:
                  "w-full px-6 py-4 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-white/50",
              }),
              React.createElement(
                "button",
                {
                  type: "submit",
                  className:
                    "absolute right-2 top-1/2 transform -translate-y-1/2 bg-atrace-orange text-white px-6 py-2 rounded-full hover:bg-atrace-orange-dark transition-colors",
                },
                "Search",
              ),
            ),
          ),
        ),
      ),

      // FAQ Section
      React.createElement(
        "section",
        { className: "py-16" },
        React.createElement(
          "div",
          { className: "container mx-auto px-4" },
          React.createElement(
            "div",
            { className: "max-w-4xl mx-auto" },
            // Detailed FAQ Accordion
            React.createElement(
              "div",
              { className: "bg-white rounded-lg shadow-md" },
              React.createElement(
                "div",
                { className: "p-6 border-b border-gray-200" },
                React.createElement(
                  "h2",
                  { className: "text-2xl font-bold text-gray-800" },
                  "Frequently Asked Questions",
                ),
              ),

              React.createElement(
                "div",
                { className: "divide-y divide-gray-200" },
                faqData.map((faq) =>
                  React.createElement(
                    "div",
                    { key: faq.id, className: "p-6" },
                    React.createElement(
                      "button",
                      {
                        onClick: () => toggleFAQ(faq.id),
                        className: "flex items-center justify-between w-full text-left",
                      },
                      React.createElement("h3", { className: "font-medium text-gray-800 pr-4" }, faq.question),
                      openFAQ === faq.id
                        ? React.createElement(ChevronUp, { className: "w-5 h-5 text-gray-500 flex-shrink-0" })
                        : React.createElement(ChevronDown, { className: "w-5 h-5 text-gray-500 flex-shrink-0" }),
                    ),

                    openFAQ === faq.id &&
                      React.createElement(
                        "div",
                        { className: "mt-4 text-gray-600" },
                        React.createElement("p", null, faq.answer),
                      ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    ),

    React.createElement(Footer),
  )
}

export default HelpPage
