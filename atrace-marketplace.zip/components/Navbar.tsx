"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Bell, ShoppingCart, Heart, User, ChevronDown } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function Navbar() {
  const { user, logout, isAuthenticated } = useAuth()
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div>
      {/* Top Navbar */}
      <nav className="bg-white border-b px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-[#FF6B35] to-[#FFA366] rounded"></div>
            <span className="text-xl font-bold text-gray-800">ATRACE</span>
          </Link>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="What items are you looking for today?"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
              />
              <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#FF6B35] text-white p-2 rounded-lg">
                <Search className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Icons */}
          <div className="flex items-center space-x-4">
            <Bell className="w-6 h-6 text-gray-600 cursor-pointer hover:text-[#FF6B35]" />
            <Link href="/cart">
              <ShoppingCart className="w-6 h-6 text-gray-600 cursor-pointer hover:text-[#FF6B35]" />
            </Link>
            <Link href="/wishlist">
              <Heart className="w-6 h-6 text-gray-600 cursor-pointer hover:text-[#FF6B35]" />
            </Link>

            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <User className="w-6 h-6" />
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/orders">Orders</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout}>Logout</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login" className="text-gray-600 hover:text-[#FF6B35]">
                  Masuk
                </Link>
                <Link href="/register">
                  <Button className="btn-primary">Daftar</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Orange Navigation Bar */}
      <nav className="navbar-orange text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center space-x-16 py-3">
            <Link href="/category" className="hover:text-orange-200 transition-colors">
              Kategori
            </Link>
            <Link href="/seller" className="hover:text-orange-200 transition-colors">
              Seller
            </Link>
            <Link href="/cart" className="hover:text-orange-200 transition-colors">
              Keranjang
            </Link>
            <Link href="/help" className="hover:text-orange-200 transition-colors">
              Bantuan
            </Link>
            <Link href="/about" className="hover:text-orange-200 transition-colors">
              About Us
            </Link>
          </div>
        </div>
      </nav>
    </div>
  )
}
