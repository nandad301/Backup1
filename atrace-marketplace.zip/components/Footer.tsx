import Link from "next/link"
import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          {/* Exclusive */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Exclusive</h3>
            <p className="text-sm text-gray-600 mb-4">Get 10% off your first order</p>
            <div className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#FF6B35]"
              />
              <button className="bg-[#FF6B35] text-white px-4 py-2 rounded-r-md hover:bg-[#E55A2B]">{"→"}</button>
            </div>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Support</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>Jl. Ring Road Utara</p>
              <p>Ngringin, Condongcatur, Kec.</p>
              <p>Depok, Kabupaten Sleman,</p>
              <p>Daerah Istimewa Yogyakarta 55281</p>
              <p>exclusive@gmail.com</p>
              <p>+6215-88888-9999</p>
            </div>
          </div>

          {/* Account */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Account</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <Link href="/profile" className="block hover:text-[#FF6B35]">
                My Account
              </Link>
              <Link href="/login" className="block hover:text-[#FF6B35]">
                Login / Register
              </Link>
              <Link href="/cart" className="block hover:text-[#FF6B35]">
                Cart
              </Link>
              <Link href="/wishlist" className="block hover:text-[#FF6B35]">
                Wishlist
              </Link>
              <Link href="/shop" className="block hover:text-[#FF6B35]">
                Shop
              </Link>
            </div>
          </div>

          {/* Quick Link */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Quick Link</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <Link href="/privacy" className="block hover:text-[#FF6B35]">
                Privacy Policy
              </Link>
              <Link href="/terms" className="block hover:text-[#FF6B35]">
                Terms Of Use
              </Link>
              <Link href="/faq" className="block hover:text-[#FF6B35]">
                FAQ
              </Link>
              <Link href="/contact" className="block hover:text-[#FF6B35]">
                Contact
              </Link>
            </div>
          </div>

          {/* Follow Us */}
          <div>
            <h3 className="font-semibold text-gray-800 mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <Facebook className="w-6 h-6 text-gray-600 hover:text-[#FF6B35] cursor-pointer" />
              <Twitter className="w-6 h-6 text-gray-600 hover:text-[#FF6B35] cursor-pointer" />
              <Instagram className="w-6 h-6 text-gray-600 hover:text-[#FF6B35] cursor-pointer" />
              <Linkedin className="w-6 h-6 text-gray-600 hover:text-[#FF6B35] cursor-pointer" />
            </div>
            <div className="mt-4">
              <div className="w-20 h-20 bg-gray-300 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
